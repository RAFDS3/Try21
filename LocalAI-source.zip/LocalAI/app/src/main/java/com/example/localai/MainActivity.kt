package com.example.localai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

data class Msg(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("localai", Context.MODE_PRIVATE)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { App(prefs) } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(prefs: android.content.SharedPreferences) {
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var game by remember { mutableStateOf(Game.MODERN_WARSHIPS) }
    val chats = remember { mutableStateMapOf<Game, List<Msg>>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var useWeb by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }
    var aKey by remember { mutableStateOf(prefs.getString("anthropic", "") ?: "") }
    var tKey by remember { mutableStateOf(prefs.getString("tavily", "") ?: "") }
    val msgs = chats[game] ?: emptyList()

    fun send() {
        val q = input.trim()
        if (q.isEmpty() || loading) return
        if (aKey.isBlank()) { showSettings = true; return }
        input = ""
        val g = game
        chats[g] = (chats[g] ?: emptyList()) + Msg("user", q)
        loading = true
        scope.launch {
            val reply = try {
                var ctx = ""
                var note = ""
                if (useWeb && tKey.isNotBlank()) {
                    ctx = try { Api.search(tKey, g, q) } catch (e: Exception) { note = "(Pencarian web gagal: ${e.message})\n\n"; "" }
                } else if (useWeb) note = "(Kunci Tavily belum diisi, jawaban tanpa web)\n\n"
                val hist = (chats[g] ?: emptyList()).map { it.role to it.text }.toMutableList()
                if (ctx.isNotBlank()) {
                    val last = hist.removeAt(hist.lastIndex)
                    hist.add(last.first to "HASIL PENCARIAN WEB:\n$ctx\nPERTANYAAN: ${last.second}")
                }
                note + Api.chat(aKey, systemPrompt(g), hist)
            } catch (e: Exception) { "Error: ${e.message}" }
            chats[g] = (chats[g] ?: emptyList()) + Msg("assistant", reply)
            loading = false
        }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("LocalAI Game Assistant", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { showSettings = true }) { Text("Pengaturan") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Game.values().forEach { FilterChip(selected = it == game, onClick = { game = it }, label = { Text(it.label) }) }
        }
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = useWeb, onCheckedChange = { useWeb = it }); Spacer(Modifier.width(8.dp)); Text("Cari di web")
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp), state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (msgs.isEmpty()) item { Text("Tanya data atau taktik ${game.label}. Contoh: \"counter terbaik untuk kapal tier tinggi?\"", Modifier.padding(16.dp)) }
            items(msgs) { m ->
                val mine = m.role == "user"
                Card(Modifier.fillMaxWidth().padding(start = if (mine) 40.dp else 0.dp, end = if (mine) 0.dp else 40.dp),
                    colors = CardDefaults.cardColors(containerColor = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                    androidx.compose.foundation.text.selection.SelectionContainer { Text(m.text, Modifier.padding(10.dp)) }
                }
            }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(8.dp)) }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Tulis pertanyaan…") }, maxLines = 4)
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !loading) { Text("Kirim") }
        }
    }

    if (showSettings) {
        var a by remember { mutableStateOf(aKey) }
        var t by remember { mutableStateOf(tKey) }
        AlertDialog(onDismissRequest = { showSettings = false },
            confirmButton = { TextButton(onClick = {
                aKey = a.trim(); tKey = t.trim()
                prefs.edit().putString("anthropic", aKey).putString("tavily", tKey).apply()
                showSettings = false
            }) { Text("Simpan") } },
            title = { Text("API Key") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(a, { a = it }, label = { Text("Anthropic API key") }, singleLine = true)
                OutlinedTextField(t, { t = it }, label = { Text("Tavily API key (web search)") }, singleLine = true)
            } })
    }
}
