package com.example.localai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}: ${text.take(300)}")
        return JSONObject(text)
    }

    /** Cari web lewat Tavily. Mengembalikan teks ringkas berisi judul, URL, dan cuplikan. */
    suspend fun search(tavilyKey: String, game: Game, q: String): String = withContext(Dispatchers.IO) {
        val r = post(
            "https://api.tavily.com/search",
            mapOf("Authorization" to "Bearer $tavilyKey"),
            JSONObject().put("query", "${game.query} $q").put("max_results", 5).put("search_depth", "basic")
        )
        val arr: JSONArray = r.optJSONArray("results") ?: JSONArray()
        buildString {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                append("[${i + 1}] ${o.optString("title")} — ${o.optString("url")}\n")
                append(o.optString("content").take(600)).append("\n\n")
            }
        }
    }

    suspend fun chat(anthropicKey: String, system: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray()
            history.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("content", text)) }
            val r = post(
                "https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to anthropicKey, "anthropic-version" to "2023-06-01"),
                JSONObject().put("model", "claude-sonnet-4-6").put("max_tokens", 1200)
                    .put("system", system).put("messages", msgs)
            )
            val c = r.getJSONArray("content")
            buildString { for (i in 0 until c.length()) append(c.getJSONObject(i).optString("text")) }
        }
}
