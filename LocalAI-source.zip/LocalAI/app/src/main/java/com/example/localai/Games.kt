package com.example.localai

enum class Game(val label: String, val query: String, val focus: String) {
    MODERN_WARSHIPS("Modern Warships", "Modern Warships game",
        "kapal, senjata (rudal, torpedo, meriam), armor, counter antar kelas kapal, strategi map, build dan upgrade."),
    MWT("MWT: Tank Battles", "MWT Tank Battles game",
        "tank, tier, senjata, armor, taktik posisi, counter, dan sistem upgrade."),
    WT_MOBILE("War Thunder Mobile", "War Thunder Mobile",
        "pesawat, tank, kapal, tier, BR, crew, modul, taktik tiap mode, dan ekonomi (SL/GE)."),
    WOT_BLITZ("World of Tanks Blitz", "World of Tanks Blitz WoT Blitz",
        "tank tiap tier dan kelas (heavy, medium, light, TD), penetrasi, armor, posisi, peran, dan taktik map."),
    BLUE_ARCHIVE("Blue Archive", "Blue Archive game",
        "karakter (stat, skill, EX, tipe serangan/pertahanan), tim untuk raid/PvP/event, banner, prioritas upgrade, dan tier list."),
}

fun systemPrompt(game: Game) = """
Kamu adalah asisten data dan taktik untuk game ${game.label}. Fokus: ${game.focus}
Aturan:
- Jawab dalam bahasa pengguna (default Bahasa Indonesia), ringkas dan terstruktur.
- Gunakan HASIL PENCARIAN WEB yang diberikan untuk angka dan data terbaru (stat, patch, meta). Sebutkan sumbernya (judul/URL).
- Jika hasil pencarian tidak memuat datanya, katakan tidak yakin. Jangan mengarang angka.
- Beri saran taktik yang konkret (posisi, urutan aksi, counter), dan sebut bahwa meta bisa berubah setelah patch.
""".trimIndent()
