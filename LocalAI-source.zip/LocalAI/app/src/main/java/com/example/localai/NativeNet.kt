package com.example.localai

object NativeNet {
    init { System.loadLibrary("localai_native") }
    external fun nativeInit(inp: Int, hid: Int, out: Int): Long
    external fun nativeTrain(h: Long, x: FloatArray, y: FloatArray, lr: Float): Float
    external fun nativePredict(h: Long, x: FloatArray): FloatArray
    external fun nativeGetWeights(h: Long): FloatArray
    external fun nativeSetWeights(h: Long, w: FloatArray)
    external fun nativeSetAffinity(mask: Int)
    external fun nativeInfo(h: Long): String
}
