// MLP kecil (1 hidden layer, tanh) dengan SGD. Dilatih langsung di perangkat.
#include <jni.h>
#include <sched.h>
#include <unistd.h>
#include <cmath>
#include <cstdlib>
#include <random>
#include <vector>
#include <string>

struct Net {
    int in, hid, out;
    std::vector<float> w1, b1, w2, b2;
    Net(int i, int h, int o) : in(i), hid(h), out(o), w1(i * h), b1(h, 0.f), w2(h * o), b2(o, 0.f) {
        std::mt19937 g(42);
        std::normal_distribution<float> n(0.f, 0.1f);
        for (auto &v : w1) v = n(g);
        for (auto &v : w2) v = n(g);
    }
    void forward(const float *x, std::vector<float> &h, std::vector<float> &y) const {
        h.assign(hid, 0.f); y.assign(out, 0.f);
        for (int j = 0; j < hid; j++) {
            float s = b1[j];
            for (int i = 0; i < in; i++) s += x[i] * w1[i * hid + j];
            h[j] = std::tanh(s);
        }
        for (int k = 0; k < out; k++) {
            float s = b2[k];
            for (int j = 0; j < hid; j++) s += h[j] * w2[j * out + k];
            y[k] = s;
        }
    }
};

static Net *N(jlong p) { return reinterpret_cast<Net *>(p); }

extern "C" {

JNIEXPORT jlong JNICALL Java_com_example_localai_NativeNet_nativeInit(JNIEnv *, jobject, jint in, jint hid, jint out) {
    return reinterpret_cast<jlong>(new Net(in, hid, out));
}

JNIEXPORT jfloat JNICALL Java_com_example_localai_NativeNet_nativeTrain(JNIEnv *env, jobject, jlong p, jfloatArray xa, jfloatArray ya, jfloat lr) {
    Net *n = N(p);
    jfloat *x = env->GetFloatArrayElements(xa, nullptr);
    jfloat *t = env->GetFloatArrayElements(ya, nullptr);
    std::vector<float> h, y;
    n->forward(x, h, y);
    std::vector<float> dy(n->out), dh(n->hid, 0.f);
    float loss = 0.f;
    for (int k = 0; k < n->out; k++) { dy[k] = y[k] - t[k]; loss += 0.5f * dy[k] * dy[k]; }
    for (int j = 0; j < n->hid; j++) {
        for (int k = 0; k < n->out; k++) {
            dh[j] += dy[k] * n->w2[j * n->out + k];
            n->w2[j * n->out + k] -= lr * dy[k] * h[j];
        }
        dh[j] *= (1.f - h[j] * h[j]);
    }
    for (int k = 0; k < n->out; k++) n->b2[k] -= lr * dy[k];
    for (int j = 0; j < n->hid; j++) {
        for (int i = 0; i < n->in; i++) n->w1[i * n->hid + j] -= lr * dh[j] * x[i];
        n->b1[j] -= lr * dh[j];
    }
    env->ReleaseFloatArrayElements(xa, x, JNI_ABORT);
    env->ReleaseFloatArrayElements(ya, t, JNI_ABORT);
    return loss;
}

JNIEXPORT jfloatArray JNICALL Java_com_example_localai_NativeNet_nativePredict(JNIEnv *env, jobject, jlong p, jfloatArray xa) {
    Net *n = N(p);
    jfloat *x = env->GetFloatArrayElements(xa, nullptr);
    std::vector<float> h, y;
    n->forward(x, h, y);
    env->ReleaseFloatArrayElements(xa, x, JNI_ABORT);
    jfloatArray r = env->NewFloatArray(n->out);
    env->SetFloatArrayRegion(r, 0, n->out, y.data());
    return r;
}

JNIEXPORT jfloatArray JNICALL Java_com_example_localai_NativeNet_nativeGetWeights(JNIEnv *env, jobject, jlong p) {
    Net *n = N(p);
    std::vector<float> all;
    for (auto *v : {&n->w1, &n->b1, &n->w2, &n->b2}) all.insert(all.end(), v->begin(), v->end());
    jfloatArray r = env->NewFloatArray((jsize) all.size());
    env->SetFloatArrayRegion(r, 0, (jsize) all.size(), all.data());
    return r;
}

JNIEXPORT void JNICALL Java_com_example_localai_NativeNet_nativeSetWeights(JNIEnv *env, jobject, jlong p, jfloatArray wa) {
    Net *n = N(p);
    jsize len = env->GetArrayLength(wa);
    size_t need = n->w1.size() + n->b1.size() + n->w2.size() + n->b2.size();
    if ((size_t) len != need) return;
    jfloat *w = env->GetFloatArrayElements(wa, nullptr);
    size_t o = 0;
    for (auto *v : {&n->w1, &n->b1, &n->w2, &n->b2})
        for (auto &e : *v) e = w[o++];
    env->ReleaseFloatArrayElements(wa, w, JNI_ABORT);
}

JNIEXPORT void JNICALL Java_com_example_localai_NativeNet_nativeSetAffinity(JNIEnv *, jobject, jint mask) {
    cpu_set_t set; CPU_ZERO(&set);
    for (int i = 0; i < 32; i++) if (mask & (1 << i)) CPU_SET(i, &set);
    sched_setaffinity(0, sizeof(set), &set);
}

JNIEXPORT jstring JNICALL Java_com_example_localai_NativeNet_nativeInfo(JNIEnv *env, jobject, jlong p) {
    Net *n = N(p);
    std::string s = "MLP " + std::to_string(n->in) + "-" + std::to_string(n->hid) + "-" + std::to_string(n->out) +
                    ", CPU: " + std::to_string(sysconf(_SC_NPROCESSORS_ONLN));
    return env->NewStringUTF(s.c_str());
}
}
