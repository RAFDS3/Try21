# LocalAI Game Assistant
Asisten AI + pencarian web untuk Modern Warships, MWT, War Thunder Mobile, World of Tanks Blitz, Blue Archive.
Build: push ke GitHub, buka tab Actions > "Build APK" > unduh artifact `LocalAI-debug-apk`.
Di aplikasi: Pengaturan > isi Anthropic API key dan Tavily API key (https://tavily.com).
`NativeNet` (C++/JNI) = MLP kecil yang dilatih di perangkat, direkonstruksi dari fungsi native APK asli.
